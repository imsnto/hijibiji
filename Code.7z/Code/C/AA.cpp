void solve()
{
    vector <pair<int,int>> vp;
    vi v;
    int n, a, b, c = 1;
    cin >> n;
    while(n--)
    {
        cin >> a >> b;
        vp.pb({b,a});
    }
    sort(vp.begin(),vp.end());
    cout << endl;
    for (auto it:vp)
    {
        //cout << it.ss << " " << it.ff << endl;
        v.pb((it.ss));
        v.pb((it.ff));
    }
    int f = v[1];
    for (int i = 2; i < v.size(); i += 2)
    {
        //cout << v[i] << " ";
        if (f <= v[i])
        {
            f = v[i+1];
            c++;
        }
    }
    cout << c << endl;
}
