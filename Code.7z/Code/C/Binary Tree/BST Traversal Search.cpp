#include<bits/stdc++.h>
using namespace std;

struct Node{
    int val;
    Node* left;
    Node* right;

    Node(int data){
        val = data;
        left = right = NULL;
    }
};

Node* Insert(Node* root, int data){
    if(root == NULL){
        Node* newNode = new Node(data);
        root = newNode;
        return root;
    }
    if(root->val >= data)
        root->left = Insert(root->left, data);
    else
        root->right = Insert(root->right, data);
    return root;
}
bool search(Node* root, int data){
    if(root == NULL) return false;
    if(root->val == data) return true;

    if(root->val >= data)
        return search(root->left, data);
    else
        return search(root->right, data);
}
//dfs -> inorder, preorder, postorder
void dfs(Node* root){
    if(root == NULL) return;
    cout << root->val << " ";
    dfs(root->left);
    dfs(root->right);
}
// bfs -> level order
void bfs(Node* root){
    if(root == NULL)    return;

    queue<Node*> q;
    q.push(root);

    while(!q.empty()){
            Node* current = q.front();
            cout << current->val << " ";

            if(current->left != NULL)   q.push(current->left);
            if(current->right != NULL)  q.push(current->right);
            q.pop();
        }
}

int findHeight(Node* root){
    if(root == NULL) return -1;

    int lft =  1 + findHeight(root->left);
    int rght = 1 + findHeight(root->right);

    return max(lft, rght);
}
bool isBstUtil(Node* root, int mn, int mx){
    if(root == NULL) return true;

    if(root->val >= mn && root->val < mx &&
            isBstUtil(root->left, mn, root->val) && isBstUtil(root->right, root->val, mx))
            return true;
    return false;
}
bool isBst(Node* root){
    return isBstUtil(root, INT_MIN, INT_MAX);
}

int main(){
    Node* root = NULL ;
    Node *newN = new Node(100);
    root = newN;
    Node *nn = new Node(115);
    root->right = nn;
    int n;
    cin >> n;
    for(int i=0; i<n; i++){
        int a;
        cin >> a;
        root = Insert(root, a);
    }

    dfs(root); cout << endl;
    bfs(root); cout << endl;

    int h = findHeight(root);
    cout << h << endl;

    cout << isBst(root) << endl;

    for(int i=0; i<5; i++){
        int tar;
        cin >> tar;
        if(search(root, tar))
            cout << "Found\n";
        else
            cout << "Not Found\n";
    }


    return 0;
}
