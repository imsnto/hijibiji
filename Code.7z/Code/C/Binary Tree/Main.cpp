#include <iostream>
#include <string>
#include<graphics.h>
#include "Init.hpp"
using namespace std;

int main(){
    cout << "e";
    Init ob(5);
    cout << 10;
    return 0;
}
