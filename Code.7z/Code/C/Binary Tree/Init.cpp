#include "Init.hpp"

class Init{
public:
    Init(){
            int driver = DETECT, mode;
            initgraph(&driver, &mode, "");
    }
}
