#include "Init.hpp"

class Init{
public:
    Init(int a){
            int driver = DETECT, mode;
            initgraph(&driver, &mode, "");
    }
};
