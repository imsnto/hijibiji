#include<bits/stdc++.h>
using namespace std;

struct Node{
    int val;
    Node* left;
    Node* right;

    Node(int data){
        val = data;
        left = right = NULL;
    }
};

Node* Insert(Node* root, int data){
    if(root == NULL){
        Node* newNode = new Node(data);
        root = newNode;
        return root;
    }
    if(root->val >= data)
        root->left = Insert(root->left, data);
    else
        root->right = Insert(root->right, data);
    return root;
}
bool search(Node* root, int data){
    if(root == NULL) return false;
    if(root->val == data) return true;

    if(root->val >= data)
        return search(root->left, data);
    else
        return search(root->right, data);
}
//dfs -> inorder, preorder, postorder
void dfs(Node* root){
    if(root == NULL) return;
    cout << root->val << " ";
    dfs(root->left);
    dfs(root->right);
}
// bfs -> level order
void bfs(Node* root){
    if(root == NULL)
        return;
    queue<Node*> q;
    q.push(root);

    while(!q.empty()){
        int sz = q.size();
        for(int i=0; i<sz; i++){
            Node* tp = q.front();
            q.pop();

            cout << tp->val << " ";
            if(tp->left != NULL)
                q.push(tp->left);
            if(tp->right != NULL)
                q.push(tp->right);
        }
    }
}

int main(){
    Node* root = NULL ;
    int n;
    cin >> n;
    for(int i=0; i<n; i++){
        int a;
        cin >> a;
        root = Insert(root, a);
    }

    dfs(root); cout << endl;
    bfs(root); cout << endl;

    for(int i=0; i<5; i++){
        int tar;
        cin >> tar;
        if(search(root, tar))
            cout << "Found\n";
        else
            cout << "Not Found\n";
    }

    return 0;
}
