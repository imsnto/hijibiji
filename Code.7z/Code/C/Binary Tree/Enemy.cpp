class Enemy{
public:

}
