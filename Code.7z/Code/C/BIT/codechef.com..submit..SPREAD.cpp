#include<bits/stdc++.h>
using namespace std;


#define int long long

vector<int> bit;
int n, m, c;

void upd(int id, int val){
    while(id <= n){
        bit[id] += val;
        id += (id & -id);
    }
}

int sum(int id){
    int s = 0;
    while(id > 0){
        s += bit[id];
        id -= (id & -id);
    }
    return s;
}

int32_t main(){
    scanf("%ld%ld%ld", &n, &m, &c);
    bit.resize(n+1);

    for(int i=0; i<m; i++){
        char ch;
        scanf("%c", &ch);
        if(ch == 'S'){
            int u, v, k;
            scanf("%ld%ld%ld", &u, &v, &k);
            upd(u, k);
            upd(v+1, -k);
        }
        else {
            int id;
            scanf("%ld", &id);
            printf("%ld\n", c + sum(id));
        }
    }
}
