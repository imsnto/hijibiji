#include<bits/stdc++.h>
using namespace std;

const int mxn = 100;
int mat[mxn][mxn];
int par[mxn];
int color[mxn];
int v;

void dfs(int s){
    color[s] = 1;
    cout << s << " ";

    for(int i=0; i<v; i++){
        if(mat[s][i] == 1 && color[i] == 0){
            dfs(i);
        }
    }
    color[s] = 2;
}

int main(){
    int  e;
    cin >> v >> e;

    for(int i=0; i<e; i++){
        int u, v;
        cin >> u >> v;
        mat[u][v] = 1;
        mat[v][u] = 1;
    }

    for(int i=0; i<v; i++){
        if(color[i] == 0){
            dfs(i);
        }
    }

    return 0;
}
