#include<bits/stdc++.h>
using namespace std;


const int mxn = 1005;
vector<int> adj[mxn];
vector<bool> vis(mxn);

void dfs(int s){
    if(vis[s]) return;

    cout << s << " ";
    vis[s] = true;

    for(int u : adj[s]){
        dfs(u);
    }
}

int main(){
    int n, e;
    cin >> n >> e;

    for(int i=0; i<e; i++){
        int u, v;
        cin >> u >> v;
        adj[u].push_back(v);
        adj[v].push_back(u);
    }

    for(int i=0; i<n; i++){
        if(vis[i] == false){
            dfs(i);
        }
    }
    return 0;
}
