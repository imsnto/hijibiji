#include<bits/stdc++.h>
using namespace std;

bool bfs(vector<vector<int>>& adj, vector<int> &vis){
    queue<pair<int,int>> q;
    q.push({0, -1});
    vis[0] = 1;

    while(!q.empty()){


        int  u = q.front().first;
        int v = q.front().second;
        q.pop();

        for(int d: adj[u]){
            if(d == v) continue;
            if(vis[d] == 1) return true;
            vis[d] = 1;
            q.push({d, u});
        }
    }
    return false;
}
bool dfs(int node, int parent, vector<vector<int>>& adj, vector<int> &vis){
    vis[node] = 1;

    for(int child: adj[node]){
        if(vis[child] == 0){
            if(dfs(child, node, adj, vis))
                return true;
        }
        else if(child != parent) return true;
    }
    return false;
}

int main(){
    int n, m;
    cin >> n >> m;

    vector<vector<int>> adj(n, vector<int>());
    for(int i=0; i<m; i++){
        int u, v;
        cin >> u >> v;
        adj[u].push_back(v);
        adj[v].push_back(u);
    }

    vector<int> vis(n, 0);
    bool isCycle = dfs(0, -1, adj, vis);
    cout << isCycle << endl;



    return 0;
}
/*
6  6
0 1
1 4
3 2
2 5
0 3
1 2
*/
