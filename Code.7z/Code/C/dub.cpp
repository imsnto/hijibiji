#include<bits/stdc++.h>
using namespace std;

#define int  long long

int32_t main(){
    int t; cin >> t; while(t--)
    {

    }


    return 0;
}


