#include <bits/stdc++.h>
using namespace std;

vector<int> ar;
vector<int> ans;

void subset(int st, int n){
    if(st == n){
        for(int d: ans){
            cout << d << " ";
        }
        cout << endl;
        return;
    }
    ans.push_back(ar[st]);
    subset(st+1, n);
    ans.pop_back();
    subset(st+1, n);
}

int main(){
    int n;
    cin >> n;

    ar.resize(n);

    for(int i=0; i<n; i++) cin >> ar[i];

    subset(0, n);

    return 0;
}
