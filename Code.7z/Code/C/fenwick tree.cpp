#include<bits/stdc++.h>
using namespace std;


#define int long long

vector<int> arr, ar;
int n, m;

void update(int idx, int val){
    while(idx <= n){
        ar[idx] += val;
        idx += (idx & -idx);
    }
}
int sum(int idx){
    int s = 0;
    while(idx > 0){
        s += ar[idx];
        idx -= (idx & -idx);
    }
    return s;
}

int32_t main(){
    cin >> n >> m;

    ar.resize(n+5);
    arr.resize(n+5);

    for(int i=1; i<=n; i++){
        cin >> arr[i];
        update(i, arr[i]);
    }

    for(int i=0; i<m; i++){
        int a;
        cin >> a ;
        if(a == 2){
            int l, r;
            cin >> l >> r;
            cout << sum(r) - sum(l-1) << endl;
        }
        else{
            int k , u;
            cin >> k >> u;

            int aa = u;

            u -= arr[k] ;
            arr[k] = aa;

            update(k, u);
        }
    }

    return 0;
}
