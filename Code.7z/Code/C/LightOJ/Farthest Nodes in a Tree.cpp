#include<bits/stdc++.h>
using namespace std;


#define int             long long
const int mxn = 505;
vector<vector<pair<int, int>>> adj(mxn, vector<pair<int, int>> (mxn));
vector<bool> vis(mxn);
char arr[25][25];

int mx = 0;

void dfs(int nd){
    if(vis[nd]) return;
    vis[nd] = true;
    mx += adj[nd].second;

    for(auto u: adj[nd])
        dfs(u);
}

int32_t main(){
    int t; cin >> t;
    for(int l=0; l<t; l++){
        int n;
        cin >> n;
        int s = 0;

        for(int i=0; i<n; i++){
            int a, b, c;
            cin >> a >> b >> c;
            adj[a].push_back({b, c});
            s += c;
        }

        int mn = INT_MAX;
        for(int i=1; i<=n; i++){
            memset(vis, false, sizeof(vis));
            mx = 0;
            dfs(i);

            mn = min(mn, s - mx);
        }

        cout << "Case " << l+1 << ": " << mn << endl;
    }

    return 0;
}

