#include<bits/stdc++.h>
using namespace std;

#define int long long
const int MXN = 100005;
int ar[MXN];
int tree[4*MXN];

void init(int node, int b, int e){
    if(b == e){
        tree[node] = ar[b];
        return;
    }
    int m = b + (e - b) / 2;
    int left = 2*node;
    int right = left + 1;

    init(left, b, m);
    init(right, m+1, e);

    tree[node] = min(tree[left] , tree[right]);
}

int query(int node, int b, int e, int i, int j){
    if(e<i || j<b) return INT_MAX;
    if(b>=i && e<=j) return tree[node];

    int m = b + (e - b) / 2;
    int left = 2*node;
    int right = left + 1;

    int p = query(left, b, m, i, j);
    int q = query(right, m+1, e, i, j);

    return min(p, q);
}
int32_t main(){
    int k = 1;
    int t; cin >> t; while(t--){
    cout << "Case " << k++ << ":\n";

    int n, q;
    cin >> n >> q;


    for(int i=1; i<=n; i++)
        cin >> ar[i];
    init(1, 1, n);

    for(int i=1; i<=q; i++){
        int a, b;
        cin >> a >> b;
        int ans = query(1, 1, n, a, b);
        cout << ans << endl;
    }
    }
    return 0;
}
