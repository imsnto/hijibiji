#include<bits/stdc++.h>
using namespace std;

#define int long long
const int MXN = 100005;
int ar[MXN];
int tree[4*MXN];
int ans = 0;

void init(int node, int b, int e){
    if(b == e){
        tree[node] = ar[b];
        return;
    }
    int m = b + (e - b) / 2;
    int left = 2*node;
    int right = left + 1;

    init(left, b, m);
    init(right, m+1, e);

    tree[node] = tree[left] + tree[right];
}

int query(int node, int b, int e, int i, int j){
    if(e<i || j<b) return 0;
    if(b>=i && e<=j) return tree[node];

    int m = b + (e - b) / 2;
    int left = 2*node;
    int right = left + 1;

    int p = query(left, b, m, i, j);
    int q = query(right, m+1, e, i, j);

    return p + q;
}

void update(int node, int b, int e, int idx , int val, bool f ){
    if(e<idx || b>idx) return;
    if(idx<=b && idx>=e){
        if(f){
        ans = tree[node];
        tree[node] = 0;
        }
        tree[node] += val;
        return;
    }

    int m = b + (e - b) / 2;
    int left = 2*node;
    int right = left + 1;
    update(left, b, m, idx, val, f);
    update(right, m+1, e, idx, val, f);

    tree[node] = tree[left] + tree[right];

}

int32_t main(){
    int k = 1;
    int t; cin >> t; while(t--){
    memset(tree, 0, 4*MXN);
    memset(ar, 0, MXN);
    cout << "Case " << k++ << ":\n";

    int n, q;
    cin >> n >> q;


    for(int i=1; i<=n; i++)
        cin >> ar[i];
    init(1, 1, n);

    for(int i=1; i<=q; i++){
        int op;
        cin >> op;

        if(op == 1){
            int v;
            cin >> v;
            update(1, 1, n, v+1, 0, true);
            cout << ans << endl;
            //ar[v+1] = 0;
        }
        else if(op == 2){
            int idx, v;
            cin >> idx >> v;
            update(1, 1, n, idx+1, v, false);
        }
        else{
            int u, v;
            cin >> u >> v;
            cout << query(1, 1, n, u+1, v+1) << endl;
        }
    }
    }
    return 0;
}

